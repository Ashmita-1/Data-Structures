/*
QUESTION-22:
            Write a program to create a Threaded Binary Tree as per inorder traversal, and implement operations
            like finding the successor / predecessor of an element, insert an element, inorder traversal.
SOLUTION:
*/
